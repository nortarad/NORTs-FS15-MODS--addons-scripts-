﻿--clodHudHider v1.15
--ls15 version
--http://forum.tractor-italia.net


Chud = {}
Chud.modDir = g_currentModDirectory;

Chud.hideHud       = false;


function Chud:loadMap(name)
    if self.initialized then
        
        return;
    end;
 
        
    self.initialized = true;
end;

function Chud:deleteMap()
    self.initialized = false;
end;

function Chud:load(xmlFile)
end;

function Chud:delete()
end;



function Chud:mouseEvent(posX, posY, isDown, isUp, button)
end;

function Chud:keyEvent(unicode, sym, modifier, isDown)
end;

function Chud:update(dt)
   
    if InputBinding.hasEvent(InputBinding.ChudHideHud) then
	
	
        
        Chud.hideHud = not Chud.hideHud
        g_currentMission.showHelpText        = not Chud.hideHud;
        g_currentMission.showVehicleInfo     = not Chud.hideHud;
        g_currentMission.showHudEnv          = not Chud.hideHud;
        g_currentMission.renderTime          = not Chud.hideHud;
        g_currentMission.showWeatherForecast = not Chud.hideHud;
		g_currentMission.showVehicleSchema       = not Chud.hideHud;
      
    end;
end;






function Chud:draw()
    
      
end;

addModEventListener(Chud);

print("HUD Hider by Clod-http://forum.tractor-italia.net loaded");