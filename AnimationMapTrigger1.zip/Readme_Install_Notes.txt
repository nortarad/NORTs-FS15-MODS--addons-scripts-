+++++++++++++++++++++++++++++++++++++++++++++++++++++++

			          English
					  
+++++++++++++++++++++++++++++++++++++++++++++++++++++++



--------------------------------------------------
				Before Starting!
--------------------------------------------------
0.0. I won't go into detail how to setup every little feature but I will explain what you can do with the "AnimationMap.xml"

0.1. The "AnimationMap.xml" is not needed to work if you intend to use the default features available with the AnimationMapTrigger mod. Skip to 5.0.


--------------------------------------------------
				Moving File
--------------------------------------------------

1.1. Copy the file "AnimationMap.xml" to your root map folder.

1.2. Open your map lua file and place this line 

		self.AnimationMapConfig = {"AnimationMap.xml", self.baseDirectory};

after this line

		self.vehicleShopBase = nil;
		
1.3. This part is an notice message that's printed in log if the AnimationMapTrigger mod is not in mods folder. In your map lua file, place this line 

		if _G["AnimationMapTrigger"] == nil then print("  AnimationMapTrigger - Notice: The mod AnimationMapTrigger is missing from your mods folder, get your copy at http://vertexdezign.net/"); end;

after this line

		self:finishLoadingTask();
		
--------------------------------------------------
Explaining What You Can DO With "AnimationMap.xml"
--------------------------------------------------

-- Debug --
2.1. Uncomment this part
        
		<Config debug="true" />

Will enable various information on what's being loaded etc and is printed in log file.


-- Global Text --
3.0. The reason why this is here is because as it works now then all texts that "negText and "posText" use must be located in the modDesc file of AnimationMapTrigger.zip, this feature makes it possible to still use text if they are added to these xml tags I will show you below.

3.1. To add new l10n text, you simple add them to you maps modDesc file and add the name of that I10n into the "AnimationMap.xml" like following

AnimationMap.xml:	
		<GlobalTexts>
			<text name="CLOSE_GATE" />
		</GlobalTexts>

modDesc:		
		<text name="CLOSE_GATE" >
			<en>close gate</en>
			<de>Weidetor schlie�en</de>
		</text>

3.2. You can now use the text defined with the userAttributes "negText and "posText".

-- Custom Trigger Hud --
4.0. Show your unique hud when trigger can be activated.

4.1. Add an new hud by giving it an unique name if this is not done then the last added hud with that name will be used.

4.2. To use this new hud in trigger, add the unique name  to the "hudOverlayName" userAttribute.

Note: Your new hud shall be placed in your map direction.


--------------------------------------------------
				CollisionMask
--------------------------------------------------
Only Player controlled:			Bit 20, CollisionMask: 100000
Only vehicle controlled:        Bit 21-24 and 26, CollisionMask: 5e00000
Player and vehicle controlled: 	Bit 20-24 and 26, CollisionMask: 5f00000


--------------------------------------------------
				Notes
--------------------------------------------------

Note 1: AnimationNode
The first child of the trigger must be an node that has an animation!

Note 2: open/close hours
Setting openTime and closeTime to 0 will disable this feature all together.

Note 3: No editing to the AnimationMapTrigger.zip is needed!

Note 4: There are a few pre set triggers included, look in the folder "Different_Trigger_Settings".

Note 5: "OPEN_DOOR", "CLOSE_DOOR", "OPEN_GATE", "CLOSE_GATE", "OPEN_WINDOW" and "CLOSE_WINDOW"
are pre set and can be used with the userAttributes "negText and "posText".




+++++++++++++++++++++++++++++++++++++++++++++++++++++++

			        Deutsch
			
+++++++++++++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------------------
				Vorbereitung
--------------------------------------------------

0.0 Hier den Trigger bis ins letzte Details zu beschreiben, w�rde den Rahen sprengen.

0.1 Die AnimationMap.xml wird nur ben�tigt, wenn du extra Features wie z.B. eigene T�rnamen, oder eigene Huds benutzen willst. Wenn nicht, gehe weiter zu Schritt 5

--------------------------------------------------
				Moving File
--------------------------------------------------

1.1 Kopiere die "AnimationMap.xml" in das Map Verzeichnis.

1.2 �ffne die Map.lua und schreibe die folgende Zeile

		self.AnimationMapConfig = {"AnimationMap.xml", self.baseDirectory};

nach der Zeile

		self.vehicleShopBase = nil;

--------------------------------------------------
Explaining What You Can DO With "AnimationMap.xml"
--------------------------------------------------

-- Debug --
2.1. Mit folgender Zeile in der xml aktivierst du die debugging Funktion
        
		<Config debug="true" />

Die Informationen zu den verbauten Triggern findest du in der log.txt

-- Global Text --
3.0. Der eigene Text gibt dir die M�glichkeit verschiedene Anzeigetexte f�r verschiedene Tor selbst zu erstellen, ohne die AnimationMaptrigger.zip zu ver�ndern.

3.1. Um einen neuen Text zu erstellen gehe wie folgt vor. 


AnimationMap.xml:	<GlobalTexts>
				<text name="CLOSE_GATE" />
			</GlobalTexts>

modDesc:		<l10n>
				<text name="CLOSE_GATE" >
					<en>close gate</en>
					<de>Weidetor schlie�en</de>
				</text>
			</l10n>

3.2. Jetzt kannst du den Textnamen in posText und negText einf�gen.


-- Custom Trigger Hud --
4.0. Deine eigenen Huds f�r verschiedene Tore.

4.1. F�ge dein eigenes Hud mit einem eindeutigen Namen in das Mapverzeichnis ein.

4.2. Trage den Namen in den User Atrributen des entsprechenden Triggers ein um das Hud zu verwenden



--------------------------------------------------
				CollisionMask
--------------------------------------------------

Collusionmask:
Trigger k�nnen nur zu Fu� bedient werden: 		Bit 20, CollisionMask: 100000
Nur Fahrzeugs gesteuert:        Bit 21-24 and 26, CollisionMask: 5e00000
Trigger k�nnen auch aus einem Fahrzeug bedient werden:	Bit 20-24 and 26, CollisionMask: 5f00000

--------------------------------------------------
				Notes
--------------------------------------------------

AnimationNode:
Die AnimationNode bzw der Animation Name eurer T�r muss in den UserAttributes immer an erster Stelle stehen. 
In der Regel ist das wegen dem Namen aber automatisch so.

Oper/Close Hours:
Mit den Eintragen "openTime" und "closeTime" vom Typ integer (in Stunden) k�nnen �ffnungszeiten eingestellt werden. 
Standardm��ig sind T�ren von 0-24 Uhr auf. Diese Eintr�ge sind optional.
