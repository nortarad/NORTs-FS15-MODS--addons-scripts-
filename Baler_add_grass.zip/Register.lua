SpecializationUtil.registerSpecialization("balerAddgrass", "balerAddgrass", g_currentModDirectory.."balerAddgrass.lua");

register = {};
function register:loadMap(name)
 for k, v in pairs(VehicleTypeUtil.vehicleTypes) do
 if SpecializationUtil.hasSpecialization(Baler, v.specializations) then
 table.insert(v.specializations, SpecializationUtil.getSpecialization("balerAddgrass"));
 end;
 end;
end;

function register:deleteMap()
end;

function register:keyEvent(unicode, sym, modifier, isDown)
end;

function register:mouseEvent(posX, posY, isDown, isUp, button)
end;

function register:update(dt)
end;

function register:draw()
end;

addModEventListener(register);