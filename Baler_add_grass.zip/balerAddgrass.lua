balerAddgrass = {};

function balerAddgrass.prerequisitesPresent(specializations)
 return true;
end;

function balerAddgrass:load(xmlFile)
 self.fillTypes[Fillable.FILLTYPE_GRASS_WINDROW] = true;
 table.insert(self.balerPickupFillTypes, Fillable.FILLTYPE_GRASS_WINDROW);
 self.baleTypes[Fillable.FILLTYPE_GRASS_WINDROW] = self.baleTypes[Fillable.FILLTYPE_DRYGRASS_WINDROW];
end;

function balerAddgrass:delete()
end;

function balerAddgrass:mouseEvent(posX, posY, isDown, isUp, button)
end;

function balerAddgrass:keyEvent(unicode, sym, modifier, isDown)
end;

function balerAddgrass:update(dt)
end;

function balerAddgrass:draw()
end;