Incpector (v1)
BigBrother f�rs LS.

Wollt ihr wissen was andere Spieler Machen? Oder brauchen eure Helfer Aufsicht?
Kein Problem. Dieser Mod zeigt euch das alles schon �bersichtlich an.

Folgendes wird angezeigt:
- dein Fahrzeug,
- alle Vehikel die mit Helfern unterwegs sind,
- alle M�hdrescher, die was im Korntank haben.

Bei jedem davon wird der Fahrzeugname angezeigt, zusammen mit angeschlossenen Ger�ten, dazu noch ob der Helfer aktiv ist oder nicht.
Wenn ein anderer Spieler drin sitzt, wird auch sein Name angezeigt (im Multiplayer).
Bei M�hdreschern wird angezeigt was drin ist und wie viel (in Prozent).
Beispiel: (edmund) Lizard 58 + Schneidwerk [H] @22% (Weizen)

Es gibt auch Farben:
- Hellblau = Helfer,
- schmutziges orange = Korntank �ber 80%,
- Wei� = kontrolliert von einem Spieler, wenn es in Fettschrift ist, dann von dir selbst.

Alt+A - anzeige ein/aus.
Funktioniert zusammen mit meinem Switcher V2 (http://forum.landwirtschafts-simulator.de/viewtopic.php?f=431&t=29899), die Inspector Liste wird ausgeblendet wenn Alt gedr�ckt wird.

Der Mod kann unter Verwendung des original Links �berall released werden. 

----------------

Inspector V1
BigBrother for LS.

Do you want to know what other Players are doing? Or you need to keep an eye on your AI helpers?
No problem. This mod shows you all of this in a nice list.

Vehicles included in the list:
- your own vehicle,
- every vehicle that is controlled by a helper,
- every cutter that has something in the grain tank.

Every entry shows the vehicle name, attached appliances, also if the helper is active.
If another player controls it, his name will be shows also (in Multiplayer mode).
Cutters get additional info about what they have in the grain tank and how much (in percent).
Example: (edmund) Lizard 58 + Cutter [H] @65% (Barley)

There is also colour:
- light blue = helper,
- dirty orange = grain tank over 80%,
- white = controlled by a player, if bold, it's controlled by you.

Alt+A - toggle display on/off.
Works with my Switcher V2 (http://forum.landwirtschafts-simulator.de/viewtopic.php?f=431&t=29899), the Inspector list is hidden when Alt is pressed.

The mod can be released everywhere, but you need to use the original link.