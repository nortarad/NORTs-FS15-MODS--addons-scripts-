Hired Workers Consumes Fuel and Seeds

Remember to check the support topic for any additional information regarding this mod.

Changelog
v0.92
- Updated to FS2013, requires patch 1.4.0.x
- Stops hired worker, if sowing-machine/sprayer is empty or fuel is 1% or less.


Mod description

Are you annoyed at the hired workers somehow magically do not use any seeds or fuel. This little mod changes that, so they now do. 

For those that remember the previous version for FS2011, the hired workers in FS2013 have now been educated so they now stop, when they notice the seeds run dry or there is less than 1% fuel left.


Problems or bugs?

If you encounter problems or bugs using the 'Hired Workers Consume Fuel & Seeds' mod, please use the support-thread at http://fs-uk.com - Find the mod (and correct version) in the mods section, in category 'Other - Game Scripts'.

Known defects/bugs:
- None as of yet.


Restrictions

This mod's files MUST NOT be embedded in any other mod. - However it is accepted if this mod is included in a mod-pack, when this mod's original hash-value is kept intact.

Please do NOT upload this mod to any other hosting site - I can do that myself, when needed!

Keep the original download link!